﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace MvcMusic.Models
{
    public class Music
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        [DataType(DataType.Date)]
        public DateTime ReleaseDate { get; set; }
        [Display(Name = "Release Date")]
        
        public string? Genre { get; set; }
        
        public decimal Price { get; set; }
        public decimal Rating { get; set; }
    }
}
