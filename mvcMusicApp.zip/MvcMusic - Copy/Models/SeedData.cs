﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcMusic.Data;
using MvcMusic.Models;
using System;
using System.Linq;

namespace MvcMovie.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new MvcMusicContext(
            serviceProvider.GetRequiredService<
                DbContextOptions<MvcMusicContext>>()))
        {
            // Look for any movies.
            if (context.Music.Any())
            {
                return;   // DB has been seeded
            }
            context.Music.AddRange(
                new Music
                {
                    Title = "Eternal Sunshine",
                    
                    ReleaseDate = DateTime.Parse("2024-3-8"),
                    Genre = "Pop/Contemporary R&B",
                    Rating= 5/5,
                    Price = 7.99M
                },
                new Music
                {
                    Title = "Careless Whisper",
                    
                    ReleaseDate = DateTime.Parse("1984-7-23"),
                    Genre = "Pop/Contemporary R&B",
                    Rating = 5/5,
                    Price = 7.99M
                },
                new Music
                {
                    Title = "Something in the way",
                    
                    ReleaseDate = DateTime.Parse("1991-9-13"),
                    Genre = "Acoustic Rock",
                    Rating = 5/5,
                    Price = 8.99M
                },
                new Music
                {
                    Title = "DIE 4 YOU",
                    
                    ReleaseDate = DateTime.Parse("2023-11-18"),
                    Genre = "R&B/Soul",
                    Rating = 4/5,
                    Price = 9.99M
                },
                new Music
                {
                    Title = "Fluorescent Adolescent",
                    
                    ReleaseDate = DateTime.Parse("2007-7-9"),
                    Genre = "Alternative/Indie,Rock",
                    Rating = 3/5,
                    Price = 3.99M
                }
            );
            context.SaveChanges();
        }
    }
}
