using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MvcMusic.Views.Home
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
